unit uventana;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls,
  utexto;

type

  { TFormTexto }

  TFormTexto = class(TForm)
    LTITULO: TLabel;
    LNOM: TLabel;
    LBUSCAR: TLabel;
    LNUEVA: TLabel;
    LNOM2: TLabel;
    LSAL: TLabel;
    LCONT: TLabel;
    LRES: TLabel;
    FNOM: TEdit;
    FNOM2: TEdit;
    FSAL: TEdit;
    EBUSCAR: TEdit;
    ENUEVA: TEdit;
    BGRABAR: TButton;
    BLEER: TButton;
    BBUSCAR: TButton;
    BREEMPLAZAR: TButton;
    BPALABRAS: TButton;
    BPARRAFOS: TButton;
    BMEZCLAR: TButton;
    BSALIR: TButton;
    MCONT: TMemo;
    MRES: TMemo;
    procedure BBUSCARClick(Sender: TObject);
    procedure BGRABARClick(Sender: TObject);
    procedure BLEERClick(Sender: TObject);
    procedure BMEZCLARClick(Sender: TObject);
    procedure BPALABRASClick(Sender: TObject);
    procedure BPARRAFOSClick(Sender: TObject);
    procedure BREEMPLAZARClick(Sender: TObject);
    procedure BSALIRClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    T: TTexto;
    procedure Msg(const s: string);
    procedure Tomar;
  public
  end;

var
  FormTexto: TFormTexto;

implementation

{$R *.lfm}

{ TFormTexto }

procedure TFormTexto.Msg(const s: string);
begin
  MRES.Lines.Add(s);
end;

procedure TFormTexto.Tomar;
begin
  T.Lineas.Text := MCONT.Text;
end;

procedure TFormTexto.FormCreate(Sender: TObject);
begin
  SetCurrentDir(ExtractFilePath(Application.ExeName));
  T := TTexto.Create;
end;

procedure TFormTexto.FormDestroy(Sender: TObject);
begin
  T.Free;
end;

procedure TFormTexto.BGRABARClick(Sender: TObject);
begin
  Tomar;
  if T.Grabar(FNOM.Text) then
    Msg('Archivo ' + FNOM.Text + ' grabado.')
  else
    Msg('No se pudo crear el archivo ' + FNOM.Text);
end;

procedure TFormTexto.BLEERClick(Sender: TObject);
begin
  if T.Leer(FNOM.Text) then
  begin
    MCONT.Text := T.Lineas.Text;
    Msg('Archivo ' + FNOM.Text + ' leído.');
  end
  else
    Msg('No se pudo abrir el archivo ' + FNOM.Text);
end;

procedure TFormTexto.BPALABRASClick(Sender: TObject);
begin
  Tomar;
  Msg('Cantidad de palabras: ' + IntToStr(T.ContarPalabras));
end;

procedure TFormTexto.BPARRAFOSClick(Sender: TObject);
begin
  Tomar;
  Msg('Cantidad de párrafos: ' + IntToStr(T.ContarParrafos));
end;

procedure TFormTexto.BBUSCARClick(Sender: TObject);
var
  res: TStringList;
  n: Integer;
begin
  if Trim(EBUSCAR.Text) = '' then
  begin
    Msg('Escriba la palabra a buscar.');
    Exit;
  end;
  Tomar;
  res := TStringList.Create;
  try
    n := T.BuscarPalabra(EBUSCAR.Text, res);
    Msg('La palabra "' + EBUSCAR.Text + '" aparece ' + IntToStr(n) + ' vez/veces.');
    MRES.Lines.AddStrings(res);
  finally
    res.Free;
  end;
end;

procedure TFormTexto.BREEMPLAZARClick(Sender: TObject);
var
  n: Integer;
begin
  if Trim(EBUSCAR.Text) = '' then
  begin
    Msg('Escriba la palabra a reemplazar.');
    Exit;
  end;
  Tomar;
  n := T.ReemplazarPalabra(EBUSCAR.Text, ENUEVA.Text);
  MCONT.Text := T.Lineas.Text;
  Msg('Se reemplazó "' + EBUSCAR.Text + '" por "' + ENUEVA.Text + '": ' +
      IntToStr(n) + ' vez/veces.');
end;

procedure TFormTexto.BMEZCLARClick(Sender: TObject);
begin
  if T.Mezclar(FNOM.Text, FNOM2.Text, FSAL.Text) then
  begin
    MCONT.Text := T.Lineas.Text;
    Msg('Mezcla lista: ' + FNOM.Text + ' + ' + FNOM2.Text + ' -> ' + FSAL.Text);
  end
  else
    Msg('No se pudo mezclar. Verifique que existan ' + FNOM.Text + ' y ' + FNOM2.Text);
end;

procedure TFormTexto.BSALIRClick(Sender: TObject);
begin
  Close;
end;

end.

