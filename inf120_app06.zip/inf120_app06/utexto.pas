unit utexto;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, LazUTF8;

type
  TTexto = class
  private
    FLineas: TStringList;
  public
    constructor Create;
    destructor Destroy; override;
    function Leer(const nom: string): Boolean;
    function Grabar(const nom: string): Boolean;
    function ContarPalabras: Integer;
    function ContarParrafos: Integer;
    function BuscarPalabra(const pal: string; res: TStrings): Integer;
    function ReemplazarPalabra(const vieja, nueva: string): Integer;
    function Mezclar(const n1, n2, ns: string): Boolean;
    property Lineas: TStringList read FLineas;
  end;

implementation

function EsLetra(c: Char): Boolean;
begin
  Result := (c in ['0'..'9', 'a'..'z', 'A'..'Z']) or (Ord(c) >= 128);
end;

constructor TTexto.Create;
begin
  inherited Create;
  FLineas := TStringList.Create;
end;

destructor TTexto.Destroy;
begin
  FLineas.Free;
  inherited Destroy;
end;

function TTexto.Leer(const nom: string): Boolean;
begin
  Result := False;
  if not FileExists(nom) then Exit;
  try
    FLineas.LoadFromFile(nom);
    Result := True;
  except
    Result := False;
  end;
end;

function TTexto.Grabar(const nom: string): Boolean;
begin
  try
    FLineas.SaveToFile(nom);
    Result := True;
  except
    Result := False;
  end;
end;

function TTexto.ContarPalabras: Integer;
var
  i, j, n: Integer;
  s: string;
  dentro: Boolean;
begin
  n := 0;
  for i := 0 to FLineas.Count - 1 do
  begin
    s := FLineas[i];
    dentro := False;
    for j := 1 to Length(s) do
      if EsLetra(s[j]) then
      begin
        if not dentro then
        begin
          n := n + 1;
          dentro := True;
        end;
      end
      else
        dentro := False;
  end;
  Result := n;
end;

function TTexto.ContarParrafos: Integer;
var
  i, n: Integer;
begin
  n := 0;
  for i := 0 to FLineas.Count - 1 do
    if Trim(FLineas[i]) <> '' then
      n := n + 1;
  Result := n;
end;

function TTexto.BuscarPalabra(const pal: string; res: TStrings): Integer;
var
  i, j, ini, n: Integer;
  s, w, buscar: string;
begin
  n := 0;
  buscar := UTF8LowerCase(Trim(pal));
  for i := 0 to FLineas.Count - 1 do
  begin
    s := FLineas[i];
    j := 1;
    while j <= Length(s) do
    begin
      if EsLetra(s[j]) then
      begin
        ini := j;
        while (j <= Length(s)) and EsLetra(s[j]) do
          j := j + 1;
        w := Copy(s, ini, j - ini);
        if UTF8LowerCase(w) = buscar then
        begin
          n := n + 1;
          res.Add('Línea ' + IntToStr(i + 1) + ', posición ' + IntToStr(ini));
        end;
      end
      else
        j := j + 1;
    end;
  end;
  Result := n;
end;

function TTexto.ReemplazarPalabra(const vieja, nueva: string): Integer;
var
  i, j, ini, n: Integer;
  s, w, buscar, nl: string;
begin
  n := 0;
  buscar := UTF8LowerCase(Trim(vieja));
  for i := 0 to FLineas.Count - 1 do
  begin
    s := FLineas[i];
    nl := '';
    j := 1;
    while j <= Length(s) do
    begin
      if EsLetra(s[j]) then
      begin
        ini := j;
        while (j <= Length(s)) and EsLetra(s[j]) do
          j := j + 1;
        w := Copy(s, ini, j - ini);
        if UTF8LowerCase(w) = buscar then
        begin
          nl := nl + nueva;
          n := n + 1;
        end
        else
          nl := nl + w;
      end
      else
      begin
        nl := nl + s[j];
        j := j + 1;
      end;
    end;
    FLineas[i] := nl;
  end;
  Result := n;
end;

function TTexto.Mezclar(const n1, n2, ns: string): Boolean;
var
  a, b: TStringList;
begin
  Result := False;
  if not (FileExists(n1) and FileExists(n2)) then Exit;
  a := TStringList.Create;
  b := TStringList.Create;
  try
    try
      a.LoadFromFile(n1);
      b.LoadFromFile(n2);
      a.AddStrings(b);
      a.SaveToFile(ns);
      FLineas.Assign(a);
      Result := True;
    except
      Result := False;
    end;
  finally
    a.Free;
    b.Free;
  end;
end;

end.

